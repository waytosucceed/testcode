1. ALWAYS CHANGE UNIQUE KEY in {index.html, question.js, garaph.html} to GRADE_CLASS.
FOR EG., 8_21, WHERE 8 IS GRADE AND 21 IS CLASS.

2. In graph.html change {className} to G()_C().
FOR EG., G8_C21, WHERE 8 IS GRADE AND 21 IS CLASS.

3. UPDATE PHOTO - ./assests/images/dummy-img.png